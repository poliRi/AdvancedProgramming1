#include "interface.h"

class DataReaderServer {

public:
    DataReaderServer();
    int doServer();
};
