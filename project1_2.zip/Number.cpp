#include "Number.h"

Number::Number(double value) {
    this->value = value;
}

double Number::Calculate() {
   return value;
}
